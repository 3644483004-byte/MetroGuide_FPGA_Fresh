create_clock -name clk -period 20 -waveform {0 10} [get_ports {clk}]
derive_clocks

# The three application domains exchange data only through Gray-pointer FIFOs
# and held-mailbox/toggle synchronizers. Keep the SDRAM phase pair together,
# and keep HDMI pixel/serializer clocks together for their synchronous paths.
set_clock_groups -asynchronous \
    -group [get_clocks {u_system_pll/pll_inst.clkc[0]}] \
    -group [get_clocks {u_system_pll/pll_inst.clkc[1] u_system_pll/pll_inst.clkc[2]}] \
    -group [get_clocks {u_video_pll/pll_inst.clkc[0] u_video_pll/pll_inst.clkc[1]}]
