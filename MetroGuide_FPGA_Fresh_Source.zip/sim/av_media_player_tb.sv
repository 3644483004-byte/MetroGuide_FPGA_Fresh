`timescale 1ns/1ps
// Integration contract test; SD protocol and FAT parsing have separate benches.
module sd_native_reader(input clk,rst,output reg card_ready,output card_error,
 output sd_clk,inout sd_cmd,input[3:0]sd_dat,input read_start,input[31:0]read_lba,
 input[5:0]read_blocks,output read_busy,output[7:0]read_data,
 output read_valid,block_end,read_done,read_error);
 assign card_error=0;assign sd_clk=clk;assign sd_cmd=1'bz;
 assign read_busy=0;assign read_data=0;assign read_valid=0;
 assign block_end=0;assign read_done=0;assign read_error=0;
 always @(posedge clk or posedge rst) if(rst)card_ready<=0;else card_ready<=1;
endmodule

module fat32_file_stream(input clk,rst,card_ready,start,input[87:0]file_name,
 input allow_read,input[5:0]max_blocks,output reg file_open,output reg[31:0]file_size,
 output reg file_error,file_done,output reg[7:0]data,output reg data_valid,
 output reg[31:0]byte_offset,output req_valid,output[31:0]req_lba,
 output[5:0]req_blocks,input req_grant,input[7:0]sec_data,
 input sec_valid,sec_block_end,sec_done,sec_error);
 localparam N=4800;
 reg video;integer scene,open_wait,pos,burst,divider;
 reg[15:0] left_value,right_value,pixel_value;
 assign req_valid=0;assign req_lba=0;assign req_blocks=1;
 function[7:0] wav_byte(input integer p,input integer sc);
  reg[15:0] l,r;reg[31:0]value;
  begin
   value=0;
   case(p)
    0:wav_byte="R";1:wav_byte="I";2,3:wav_byte="F";
    4,5,6,7:begin value=N*4+36;wav_byte=value>>((p-4)*8);end
    8:wav_byte="W";9:wav_byte="A";10:wav_byte="V";11:wav_byte="E";
    12:wav_byte="f";13:wav_byte="m";14:wav_byte="t";15:wav_byte=32;
    16,34:wav_byte=16;20:wav_byte=1;22,30:wav_byte=2;
    24:wav_byte=128;25:wav_byte=187;29:wav_byte=238;32:wav_byte=4;
    36:wav_byte="d";37,39:wav_byte="a";38:wav_byte="t";
    40,41,42,43:begin value=N*4;wav_byte=value>>((p-40)*8);end
    default:if(p<44)wav_byte=0;else begin
      l=((p-44)/4)+sc*4096;r=-l;
      case((p-44)%4)0:wav_byte=l[7:0];1:wav_byte=l[15:8];
       2:wav_byte=r[7:0];3:wav_byte=r[15:8];endcase
    end
   endcase
  end
 endfunction
 always @(posedge clk or posedge rst) begin
  if(rst)begin file_open<=0;file_size<=0;file_error<=0;file_done<=0;
   data_valid<=0;data<=0;byte_offset<=0;open_wait<=0;pos<=0;burst<=0;divider<=0;scene<=0;video<=0;end
  else begin
   data_valid<=0;file_done<=0;
   if(start)begin
    file_open<=0;file_error<=0;pos<=0;burst<=0;divider<=0;open_wait<=5;
    video<=file_name[87:80]=="V";
    scene<=(file_name[87:80]=="V" ? file_name[79:72] : file_name[87:80])-"1";
   end else if(open_wait!=0)begin
    open_wait<=open_wait-1;
    if(open_wait==1)begin
     if(video && scene==3)file_error<=1;
     else begin file_open<=1;file_size<=video ? 3*614400 : N*4+44;end
    end
   end else if(file_open && pos<file_size) begin
    if(burst==0)begin
     if(allow_read)burst<=max_blocks*512;
    end else begin
     divider<=divider+1;
     if(divider==1)begin
      divider<=0;data_valid<=1;byte_offset<=pos;pos<=pos+1;burst<=burst-1;
      if(video)begin
       pixel_value=scene*4096+pos/614400;
       data<=pos%2 ? pixel_value[15:8] : pixel_value[7:0];
      end else data<=wav_byte(pos,scene);
      if(pos==file_size-1)begin file_done<=1;burst<=0;end
     end
    end
   end
  end
 end
endmodule

module av_media_player_tb;
 reg sys_clk=0,pixel_clk=0,rst=1,playing=1,restart_track=0;
 always #5 sys_clk=~sys_clk;always #20 pixel_clk=~pixel_clk;
 reg[1:0]scene_id=0;
 wire audio_valid,clip_end,card_ready,sd_clk,frame_clear,frame_load_start; wire [10:0] scene_frame_index;
 wire[23:0]audio_left,audio_right;wire[31:0]audio_total_samples;
 wire[7:0]media_error;tri sd_cmd;
 reg frame_load_ready=0,frame_load_done=0,frame_swap_done=0;
 wire frame_pixel_valid,frame_swap;wire[15:0]frame_pixel_rgb565; wire hdmi_audio_valid,frame_abort,transition_request; wire [23:0] hdmi_audio_left,hdmi_audio_right; reg video_frame_start=0,transition_busy=0;
 av_media_player #(.SCENE1_FRAMES(3),.SCENE2_FRAMES(3),.SCENE3_FRAMES(3),.SCENE4_FRAMES(3)) dut(.*,.sd_dat(4'hf));
 integer accepted=0,swap_delay=0,swaps=0,expected_frame=0;
always begin #16666667; video_frame_start=1; #40; video_frame_start=0; end
 reg[15:0]loaded_pixel;
 always @(posedge sys_clk)begin
  frame_load_done<=0;frame_swap_done<=0;
  if(rst||frame_clear)begin frame_load_ready<=0;accepted<=0;swap_delay<=0;expected_frame<=0;end
  else begin
   if(frame_load_start)begin accepted<=0;frame_load_ready<=1;end
   if(frame_pixel_valid&&frame_load_ready)begin
    if(accepted==0)loaded_pixel<=frame_pixel_rgb565;
    if(frame_pixel_rgb565!==(dut.active_scene*4096+dut.load_index))$fatal(1,"video pixel/order vs load_index");
    if(accepted==307199)begin frame_load_done<=1;frame_load_ready<=0;end
    else accepted<=accepted+1;
   end
   if(frame_swap)swap_delay<=5;
   else if(swap_delay!=0)begin
    swap_delay<=swap_delay-1;
    if(swap_delay==1)begin frame_swap_done<=1;swaps<=swaps+1;expected_frame<=expected_frame+1;end
   end
  end
 end
 integer audio_count=0,ends=0,expected_scene=0,last_swaps=0;
 reg[15:0]expected_left,expected_right;
 always @(posedge dut.media_reset)begin audio_count=0;expected_scene=scene_id;last_swaps=swaps;end
 always @(negedge pixel_clk)if(!rst&&audio_valid)begin
  if(scene_id!=3 && swaps==last_swaps)$fatal(1,"audio before first video swap");
  expected_left=audio_count+expected_scene*4096;expected_right=-expected_left;
  if(audio_left!=={expected_left,8'd0}||audio_right!=={expected_right,8'd0})
   $fatal(1,"audio mismatch scene%0d sample%0d got%h expected%h",expected_scene,audio_count,audio_left,{expected_left,8'd0});
  audio_count=audio_count+1;
  if(clip_end)begin
   if(audio_count!=4800)$fatal(1,"clip sample count %0d",audio_count);
   ends=ends+1;
  end
 end
 integer paused_count;
always @(posedge pixel_clk) if(!rst && audio_valid && (!hdmi_audio_valid || hdmi_audio_left!==audio_left || hdmi_audio_right!==audio_right)) $fatal(1,"HDMI audio output mismatch");
 initial begin
  #100 rst=0; wait(dut.media_reset==0); wait(swaps>=1); wait(dut.video_started_pixel); force dut.hdmi_preroll_done=1;
  wait(audio_count==500);@(negedge pixel_clk);playing=0;
  repeat(3)@(negedge pixel_clk);paused_count=audio_count;
  #2000000;if(audio_count!=paused_count)$fatal(1,"pause emitted samples");
  @(negedge pixel_clk);playing=1;
  wait(audio_count==1500);@(negedge pixel_clk);scene_id=1;restart_track=1;
  @(negedge pixel_clk);restart_track=0;
  wait(ends==1);if(media_error!=0)$fatal(1,"media error %h",media_error);
  @(negedge pixel_clk);scene_id=3;restart_track=1;
  @(negedge pixel_clk);restart_track=0;
  wait(ends==2);if(!media_error[4])$fatal(1,"missing video not reported");
  $display("AV_MEDIA_PASS samples=%0d complete_tracks=%0d swaps=%0d",audio_count,ends,swaps);$finish;
 end
 initial begin #400000000;$fatal(1,"timeout state%0d audio%0d err%h",dut.video_state,audio_count,media_error);end
endmodule


