`timescale 1ns/1ps
module playback_controller_tb;
 reg clk=0,rst=1;
 always #5 clk=~clk;
 reg key1_auto_press=0,key2_next_press=0,key3_prev_press=0,key4_play_press=0,clip_end=0;
 reg[3:0]sw_select_press=0;
 wire restart_track,playing,auto_play;wire[1:0]scene_id;
 playback_controller dut(.*);
 task step(input[3:0]sw,input[3:0]keys,input ended);
  begin
   @(negedge clk);sw_select_press=sw;
   {key4_play_press,key3_prev_press,key2_next_press,key1_auto_press}=keys;clip_end=ended;
   @(posedge clk);#1;
  end
 endtask
 task expect_state(input[1:0]scene,input play,input auto_mode,input restart);
  begin
   if({scene_id,playing,auto_play,restart_track}!=={scene,play,auto_mode,restart})
    $fatal(1,"transport got %b expected %b",{scene_id,playing,auto_play,restart_track},{scene,play,auto_mode,restart});
  end
 endtask
 initial begin
  #11;rst=0;step(0,0,0);expect_state(0,1,1,0);
  step(4'b0100,0,0);expect_state(2,1,1,1);
  step(0,4'b0010,0);expect_state(3,1,1,1);
  step(0,4'b0010,0);expect_state(0,1,1,1);
  step(0,4'b0100,0);expect_state(3,1,1,1);
  step(0,4'b1000,0);expect_state(3,0,1,0);
  step(0,4'b1000,0);expect_state(3,1,1,0);
  step(0,0,1);expect_state(0,1,1,0);
  step(0,4'b0001,0);expect_state(0,1,0,0);
  step(0,0,1);expect_state(0,0,0,0);
  step(0,4'b1000,0);expect_state(0,1,0,1);
  step(4'b0001,0,0);expect_state(0,1,0,1);
  step(0,4'b0001,0);expect_state(0,1,1,0);
  step(0,4'b0001,1);expect_state(0,0,0,0);
  step(0,4'b1000,0);expect_state(0,1,0,1);
  step(0,4'b0001,1);expect_state(1,1,1,0);
  step(0,4'b1000,1);expect_state(1,1,1,1);
  step(4'b0100,0,1);expect_state(2,1,1,1);
  $display("PLAYBACK_CONTROL_PASS wraps, direct restart, pause, auto off/end, simultaneous toggles");$finish;
 end
endmodule
