`timescale 1ns/1ps
module sd_read_arbiter_tb;
 reg clk=0,rst=1,card_ready=1;always #5 clk=~clk;
 reg a_req=0,v_req=0;reg[31:0]a_lba=17,v_lba=29;
 reg[5:0]a_blocks=4,v_blocks=8;
 wire a_grant,v_grant,host_start;wire[31:0]host_lba;wire[5:0]host_blocks;
 reg host_busy=0,host_valid=0,host_block_end=0,host_done=0,host_error=0;
 reg[7:0]host_data=0;
 wire[7:0]data;wire a_valid,a_block_end,a_done,a_error,v_valid,v_block_end,v_done,v_error;
 sd_read_arbiter dut(.*);
 task step;@(posedge clk);#1;endtask
 initial begin
  step();@(negedge clk);rst=0;a_req=1;v_req=1;
  step();if(!a_grant||v_grant||!host_start||host_lba!=17||host_blocks!=4)$fatal(1,"audio priority");
  @(negedge clk);a_req=0;host_busy=1;
  step();if(host_start)$fatal(1,"duplicate command");
  @(negedge clk);host_data=8'hcd;host_valid=1;host_block_end=1;host_done=1;host_busy=0;
  step();if(!a_valid||!a_done||!a_block_end||data!=8'hcd||v_valid||v_done)$fatal(1,"final audio bundle");
  @(negedge clk);host_valid=0;host_done=0;host_block_end=0;
  step();if(!v_grant||!host_start||host_lba!=29||host_blocks!=8||a_done||a_valid)$fatal(1,"video grant");
  @(negedge clk);v_req=0;host_busy=1;
  step();@(negedge clk);host_error=1;host_done=1;host_busy=0;
  step();if(!v_error||!v_done||a_error||a_done)$fatal(1,"video error routing");
  @(negedge clk);host_error=0;host_done=0;card_ready=0;
  step();if(dut.occupied||v_done||v_error)$fatal(1,"card clear");
  $display("SD_ARBITER_PASS priority, indivisible burst, coincident final byte/done, errors");$finish;
 end
 initial begin #5000;$fatal(1,"timeout");end
endmodule
