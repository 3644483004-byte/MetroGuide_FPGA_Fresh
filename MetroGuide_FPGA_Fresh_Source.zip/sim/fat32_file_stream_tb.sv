`timescale 1ns/1ps
module fat32_file_stream_tb;
 reg clk=0; always #5 clk=~clk;
 reg rst=1, card_ready=0, start=0, allow_read=1;
 reg [87:0] file_name="1       WAV";
 reg [5:0] max_blocks=3;
 wire file_open,file_error,file_done,data_valid,req_valid;
 wire [31:0] file_size,byte_offset,req_lba;
 wire [7:0] data;
 wire [5:0] req_blocks;
 reg req_grant=0,sec_valid=0,sec_block_end=0,sec_done=0,sec_error=0;
 reg [7:0] sec_data=0;
 fat32_file_stream dut(.*);
 integer mode=0,base=0,failures=0,monitor_pattern=0,seen=0;
 integer busy=0,wait_grant=0,transfer_index=0,transfer_limit=0;
 reg [31:0] transfer_lba;
 reg grant_gate=1,inject_error=0;
 integer data_requests=0,mount_reads=0;

 function automatic [7:0] lebyte(input integer value,input integer lane);
   lebyte=(value>>(lane*8))&255;
 endfunction
 function automatic [7:0] entry_byte(input integer entry,input integer pos);
   reg [87:0] n; integer cl,sz,attr;
   begin
     n="1       WAV";cl=10;sz=1793;attr=32;
     case(entry)
       0: begin n="1       WAV";attr=32;end
       1: begin n="1       WAV";attr=8;end
       2: begin n="1       WAV";attr=15;end
       3: begin n="1       WAV";cl=10;sz=(mode==2?20000:1793);end
       4: begin n="V1      BIN";cl=65546;sz=600;end
       5: begin n="ZERO    BIN";cl=0;sz=0;end
       6: begin n="BROKEN  BIN";cl=30;sz=1300;end
       7: begin n="BADFAT  BIN";cl=40;sz=1300;end
       8: begin n="LOOP    BIN";cl=50;sz=1300;end
       default: begin n=88'd0;cl=0;sz=0;attr=0;end
     endcase
     entry_byte=0;
     if(pos<11) entry_byte=n>>(80-pos*8);
     if(entry==0 && pos==0) entry_byte=8'he5;
     if(pos==11)entry_byte=attr;
     if(pos==20)entry_byte=lebyte(cl,2);
     if(pos==21)entry_byte=lebyte(cl,3);
     if(pos==26)entry_byte=lebyte(cl,0);
     if(pos==27)entry_byte=lebyte(cl,1);
     if(pos>=28)entry_byte=lebyte(sz,pos-28);
   end
 endfunction
 function automatic [7:0] card_byte(input integer lba,input integer pos);
   integer rel,wordid,fatvalue,off;
   begin
     card_byte=0;rel=lba-base;
     if(mode==1 && lba==0)begin
       if(pos==450)card_byte=8'h83;
       if(pos==466)card_byte=8'h0c;
       if(pos>=470&&pos<=473)card_byte=lebyte(2048,pos-470);
       if(pos>=474&&pos<=477)card_byte=lebyte(140000,pos-474);
       if(pos==510)card_byte=8'h55;
       if(pos==511)card_byte=8'haa;
     end else if(rel==0)begin
       case(pos)
         0:card_byte=8'heb;
         12:card_byte=2;
         13:card_byte=(mode==2?128:2);
         14:card_byte=32;
         16:card_byte=2;
         40:card_byte=8'h81;
         44:card_byte=2;
         510:card_byte=8'h55;
         511:card_byte=8'haa;
         default:begin end
       endcase
       if(pos>=32&&pos<=35)card_byte=lebyte((mode==2?9000000:140000),pos-32);
       if(pos>=36&&pos<=39)card_byte=lebyte(600,pos-36);
     end else if(rel>=632&&rel<1232)begin
       wordid=(rel-632)*128+pos/4;fatvalue=32'h0fffffff;
       case(wordid)
         2:fatvalue=5;
         10:fatvalue=20;
         40:fatvalue=32'h0ffffff7;
         50:fatvalue=50;
         default:begin end
       endcase
       card_byte=lebyte(fatvalue,pos%4);
     end else if(mode==2&&rel==1232)card_byte=entry_byte(pos/32,pos%32);
     else if(rel==1232||rel==1233)begin
       if(pos%32==0)card_byte=8'he5;
     end else if(rel==1238)card_byte=entry_byte(pos/32,pos%32);
     else if(rel==1248||rel==1249)begin
       off=(rel-1248)*512+pos;card_byte=(off*7+19)&255;
     end else if(rel==1268||rel==1269)begin
       off=1024+(rel-1268)*512+pos;card_byte=(off*7+19)&255;
     end else if(mode==2&&rel>=2256&&rel<2296)begin
       off=(rel-2256)*512+pos;card_byte=(off*7+19)&255;
     end else if(rel==132320||rel==132321)begin
       off=(rel-132320)*512+pos;card_byte=(off+85)&255;
     end
   end
 endfunction

 always @(negedge clk)begin
   req_grant=0;sec_valid=0;sec_done=0;sec_error=0;sec_block_end=0;
   if(rst||!card_ready)begin busy=0;wait_grant=0;end
   else if(!busy)begin
     if(req_valid&&grant_gate)begin
       if(wait_grant==2)begin
         req_grant=1;transfer_lba=req_lba;transfer_limit=req_blocks*512;
         transfer_index=0;busy=1;wait_grant=0;
         if(req_blocks<1||req_blocks>32)$fatal(1,"invalid request blocks");
         if(req_lba==0)mount_reads=mount_reads+1;
         if(dut.read_kind==5)data_requests=data_requests+1;
       end else wait_grant=wait_grant+1;
     end
   end else if(inject_error)begin sec_error=1;busy=0;inject_error=0;end
   else if(transfer_index<transfer_limit)begin
     sec_valid=1;sec_data=card_byte(transfer_lba+transfer_index/512,transfer_index%512);
     sec_block_end=(transfer_index%512==511);
     transfer_index=transfer_index+1;
     if(mode==1&&transfer_index==transfer_limit)begin sec_done=1;busy=0;end
   end else begin sec_done=1;busy=0;end
 end
 reg request_stalled=0;
 reg [31:0] held_lba;
 reg [5:0] held_blocks;
 always @(posedge clk)begin
   if(!rst&&card_ready&&request_stalled &&
      (!req_valid||req_lba!==held_lba||req_blocks!==held_blocks))
     $fatal(1,"request changed before grant");
   request_stalled<=!rst&&card_ready&&req_valid&&!req_grant;
   held_lba<=req_lba;held_blocks<=req_blocks;
 end
 always @(posedge clk)begin
   if(data_valid&&monitor_pattern!=0)begin
     if(!file_open)$fatal(1,"byte emitted before file_open");
     if(byte_offset!==seen)$fatal(1,"offset %0d expected %0d",byte_offset,seen);
     if(monitor_pattern==1 && data!==((seen*7+19)&255))
       $fatal(1,"fragment byte mismatch at %0d got %0d",seen,data);
     if(monitor_pattern==2 && data!==((seen+85)&255))
       $fatal(1,"high cluster byte mismatch at %0d got %0d",seen,data);
     seen=seen+1;
   end
 end
 task automatic pulse_start(input [87:0] name);
   @(negedge clk);#1;file_name=name;start=1;
   @(negedge clk);#1;start=0;
 endtask
 task automatic run_file(input [87:0] name,input integer length,input integer pattern,input bit bad);
   seen=0;monitor_pattern=pattern;
   pulse_start(name);
   wait(file_done||file_error);@(negedge clk);#1;
   if(file_error!==bad)$fatal(1,"unexpected file status %s error=%b",name,file_error);
   if(!bad && (file_size!==length || seen!=length))
     $fatal(1,"size/count %s size=%0d count=%0d expected=%0d",name,file_size,seen,length);
   monitor_pattern=0;
   repeat(4)@(posedge clk);
 endtask
 integer initial_mounts;
 initial begin
   repeat(3)@(negedge clk);rst=0;card_ready=1;
   // Metadata proceeds with data gating; a three-block cap is clipped to the
   // current two-sector cluster. Deleted/LFN/volume entries must be ignored.
   allow_read=0;pulse_start("1       WAV");wait(file_open);
   repeat(20)@(posedge clk);
   if(data_requests!=0)$fatal(1,"allow_read did not gate data");
   seen=0;monitor_pattern=1;allow_read=1;
   wait(file_done||file_error);@(negedge clk);#1;
   if(file_error||seen!=1793)$fatal(1,"superfloppy fragmented read failed %0d",seen);
   monitor_pattern=0;initial_mounts=mount_reads;
   run_file("V1      BIN",600,2,0);
   if(mount_reads!=initial_mounts)$fatal(1,"mount was not retained");
   run_file("ZERO    BIN",0,3,0);
   run_file("MISSING BIN",0,0,1);
   run_file("BROKEN  BIN",0,0,1);
   run_file("BADFAT  BIN",0,0,1);
   run_file("LOOP    BIN",0,0,1);
   // A restart while a file burst is in flight drains old sectors without
   // leaking bytes into the next file, whose offset starts at zero.
   pulse_start("1       WAV");
   wait(dut.state==3&&dut.read_kind==5&&dut.transfer_bytes==30);
   allow_read=0;pulse_start("V1      BIN");wait(file_open);
   seen=0;monitor_pattern=2;allow_read=1;
   wait(file_done||file_error);@(negedge clk);#1;
   if(file_error||seen!=600)$fatal(1,"inflight restart failed");monitor_pattern=0;
   // A start while waiting for grant must preserve the old request until the
   // backend accepts it, then drain it and look up the latest selected name.
   grant_gate=0;pulse_start("1       WAV");wait(req_valid);
   pulse_start("V1      BIN");repeat(4)@(posedge clk);
   allow_read=0;grant_gate=1;wait(file_open);
   seen=0;monitor_pattern=2;allow_read=1;
   wait(file_done||file_error);@(negedge clk);#1;
   if(file_error||seen!=600)$fatal(1,"pending-grant restart failed");monitor_pattern=0;
   // Backend error is terminal, followed by successful restart on cached mount.
   pulse_start("1       WAV");wait(dut.state==3&&dut.read_kind==5);
   @(negedge clk);#1;inject_error=1;wait(file_error);
   run_file("V1      BIN",600,2,0);
   // Card removal invalidates metadata; repeat on a partitioned volume with
   // the FAT32 partition in the second table entry and active FAT number one.
   @(negedge clk);#1;card_ready=0;mode=1;base=2048;
   repeat(3)@(negedge clk);#1;card_ready=1;
   run_file("1       WAV",1793,1,0);
   run_file("V1      BIN",600,2,0);
   // Largest supported cluster and burst size, and an out-of-range max_blocks
   // input which must be clamped to 32 blocks (16,384 transfer bytes).
   @(negedge clk);#1;card_ready=0;mode=2;base=0;max_blocks=63;
   repeat(3)@(negedge clk);#1;card_ready=1;
   run_file("1       WAV",20000,1,0);
   $display("PASS FAT32 stream: superfloppy + MBR, active FAT, fragmented root/file, high cluster word, gating, restarts, errors, coincident final byte/done, 128-sector clusters, 32-block bursts");
   $finish;
 end
 initial begin #5000000;$fatal(1,"simulation timeout state=%0d kind=%0d lba=%0d count=%0d",dut.state,dut.read_kind,req_lba,seen);end
endmodule
