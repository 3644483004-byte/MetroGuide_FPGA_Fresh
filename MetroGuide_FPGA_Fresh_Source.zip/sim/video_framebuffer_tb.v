`timescale 1ns/1ps
module mg_sdram (
input Clk, Clk_sft, Rst,
output reg Sdr_init_done, output Sdr_init_ref_vld, Sdr_busy,
input App_wr_en, input [20:0] App_wr_addr, input [3:0] App_wr_dm,
input [31:0] App_wr_din, input App_rd_en, input [20:0] App_rd_addr,
output Sdr_rd_en, output [31:0] Sdr_rd_dout
);
reg [31:0] mem[0:614399];
reg [9:0] valid_pipe;
reg [31:0] data_pipe[0:9];
integer i; integer init_count;
assign Sdr_busy=0;
assign Sdr_init_ref_vld=0;
assign Sdr_rd_en=valid_pipe[9];
assign Sdr_rd_dout=data_pipe[9];
always @(posedge Clk or posedge Rst) begin
 if(Rst) begin Sdr_init_done<=0; init_count<=0;valid_pipe<=0; end
 else begin
  if(init_count<20) init_count<=init_count+1; else Sdr_init_done<=1;
  if(App_wr_en) mem[App_wr_addr]<=App_wr_din;
  valid_pipe<={valid_pipe[8:0],App_rd_en};
  if(App_rd_en) data_pipe[0]<=mem[App_rd_addr];
  for(i=1;i<10;i=i+1) data_pipe[i]<=data_pipe[i-1];
 end
end
endmodule

module tb;
reg sys_clk=0, mem_clk=0, pixel_clk=0;
always #5 sys_clk=~sys_clk;
always #12 mem_clk=~mem_clk;
always #20 pixel_clk=~pixel_clk;
wire mem_clk_shift=~mem_clk;
reg rst=1, clear=0,load_start=0,pixel_valid=0,swap_request=0;
reg [15:0] pixel_rgb565=0;
wire load_ready,load_done,swap_done,visible_frame_start,video_user,video_valid,video_last;
wire [23:0] video_data;
video_framebuffer dut(.*,.load_cancel(1'b0));
integer errors=0, check_index=0, checked=0;
reg [15:0] active_mask=0;
reg check_enable=0, checking=0;
reg [15:0] expected565;
reg [23:0] expected888;
function [23:0] expand;
 input [15:0] v;
 begin expand={v[15:11],v[15:13],v[10:5],v[10:9],v[4:0],v[4:2]};end
endfunction
always @(negedge pixel_clk) begin
 if(!rst && video_valid) begin
  if(!dut.front_visible && video_data!==24'd0) begin
   $display("FAIL black before visible %h",video_data); errors=errors+1;
  end
  if(check_enable && video_user) begin checking=1; check_index=0; end
  if(check_enable && checking) begin
   expected565=(check_index & 16'hffff)^active_mask;
   expected888=expand(expected565);
   if(video_data!==expected888) begin
    if(errors<10) $display("FAIL pixel %0d got %h expected %h",check_index,video_data,expected888);
    errors=errors+1;
   end
   if(video_last !== ((check_index%640)==639)) begin
    if(errors<10) $display("FAIL last %0d",check_index);errors=errors+1;
   end
   if(check_index==307199) begin checked=checked+1;checking=0;check_enable=0; end
   else check_index=check_index+1;
  end
 end
end
task load_frame;
 input [15:0] mask;
 integer n;
 begin
  @(negedge sys_clk);load_start=1;
  @(negedge sys_clk);load_start=0;
  wait(load_ready);
  for(n=0;n<307200;n=n+1) begin
   @(negedge sys_clk); pixel_valid=1;pixel_rgb565=(n&16'hffff)^mask;
   @(posedge sys_clk);
   while(!load_ready) @(posedge sys_clk);
  end
  @(negedge sys_clk); pixel_valid=0;
  wait(load_done);
  @(negedge sys_clk);swap_request=1;
  @(negedge sys_clk);swap_request=0;
  wait(swap_done);
  active_mask=mask;check_enable=1;
 end
endtask
initial begin
 #100 rst=0;
 load_frame(16'h5a5a);
 wait(checked==1);
 load_frame(16'ha5a5);
 wait(checked==2);
 @(negedge sys_clk);clear=1;
 @(negedge sys_clk);clear=0;
 #2000;
 if(dut.front_visible!==0) begin $display("FAIL clear visible");errors=errors+1;end
 load_frame(16'h1234);
 wait(checked==3);
 if(errors==0) $display("FRAMEBUFFER_PASS frames=%0d",checked);
 else $display("FRAMEBUFFER_FAIL errors=%0d",errors);
 $finish;
end
initial begin #120000000; $display("FAIL timeout state %0d",dut.load_state);$finish;end
endmodule

