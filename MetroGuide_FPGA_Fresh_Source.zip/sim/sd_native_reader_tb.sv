`timescale 1ns/1ps
module tb_sd;
reg clk=0, rst=1;
always #5 clk=~clk;
wire sd_clk; tri1 sd_cmd;
reg [3:0] sd_dat=15;
reg card_cmd_enable=0,card_cmd_output=1;
assign sd_cmd=card_cmd_enable?card_cmd_output:1'bz;
reg read_start=0; reg [31:0] read_lba=0; reg [5:0] read_blocks=0;
wire card_ready,card_error,read_busy,read_valid,block_end,read_done,read_error;
wire [7:0] read_data;
sd_native_reader dut(.*);
integer errors=0, bytes_seen=0, blocks_seen=0;
integer mode=0, corrupt=0, expected_lba=0, expected_blocks=0;
integer command_bits=0, stops_seen=0, cmd16_seen=0;
reg [47:0] command_frame=0;
reg monitor_reads=0;
function automatic [6:0] crc7(input [135:0] bits, input integer count);
reg [6:0] c; integer i;
begin c=0;for(i=count-1;i>=0;i=i-1)c={c[5:0],1'b0}^((c[6]^bits[i])?7'h09:7'd0);crc7=c;end
endfunction
function automatic [15:0] crc16(input [15:0] c,input bit b);
begin crc16={c[14:0],1'b0}^((c[15]^b)?16'h1021:16'd0);end
endfunction
task automatic fail(input string message);
begin $display("FAIL %0t %s",$time,message);errors=errors+1;end
endtask
task automatic send_response(input [135:0] bits,input integer length);
integer i;
begin
 repeat(2) @(negedge sd_clk);
 card_cmd_enable=1;
 for(i=length-1;i>=0;i=i-1) begin
  card_cmd_output=bits[i];@(negedge sd_clk);
 end
 card_cmd_enable=0;card_cmd_output=1;
end
endtask
task automatic response48(input [5:0] idx,input [31:0] payload,input bit nocrc);
reg [47:0] word;
begin
 word={2'b00,idx,payload,7'd0,1'b1};
 word[7:1]=nocrc?7'h7f:crc7(word>>8,40);
 send_response(word,48);
end
endtask
task automatic send_blocks(input integer count,input integer lba,input bit bad_crc);
integer block_no,i,j;reg [7:0] value;reg [3:0] nibble;
reg [15:0] c0,c1,c2,c3;
begin
 repeat(2) @(negedge sd_clk);
 for(block_no=0;block_no<count;block_no=block_no+1) begin
  sd_dat=0;@(negedge sd_clk);
  c0=0;c1=0;c2=0;c3=0;
  for(i=0;i<1024;i=i+1) begin
   value=((i/2)+block_no+lba)&255;
   nibble=(i&1)?value[3:0]:value[7:4];sd_dat=nibble;
   c0=crc16(c0,nibble[0]);c1=crc16(c1,nibble[1]);
   c2=crc16(c2,nibble[2]);c3=crc16(c3,nibble[3]);
   @(negedge sd_clk);
  end
  for(j=15;j>=0;j=j-1) begin
   sd_dat={c3[j],c2[j],c1[j],c0[j]};
   if(bad_crc && j==5)sd_dat[2]=~sd_dat[2];
   @(negedge sd_clk);
  end
  sd_dat=15;repeat(3)@(negedge sd_clk);
 end
end
endtask
task automatic handle_command(input [47:0] word);
reg [5:0] cmd;reg [31:0] arg;reg [119:0] cid;reg [135:0] r2;
integer lba;
begin
 cmd=word[45:40];arg=word[39:8];
 if(word[47:46]!=1 || !word[0] || word[7:1]!=crc7(word>>8,40))fail("command frame / CRC");
 case(cmd)
  0: begin end
  8: if(mode==0)response48(8,32'h1aa,0);
  55: response48(55,32'h20,0);
  41: begin
   if(mode==0 && !arg[30])fail("SDHC HCS missing");
   if(mode==1 && arg[30])fail("legacy SDSC HCS should be clear");
   response48(63,mode==0?32'hc0ff8000:32'h80ff8000,1);
  end
  2: begin
   cid=120'h1234567890abcdef1234567890abcd;
   r2={8'h3f,cid,crc7(cid,120),1'b1};send_response(r2,136);
  end
  3: response48(3,32'h12340600,0);
  7: begin
   if(arg!=32'h12340000)fail("CMD7 RCA");
   response48(7,32'h900,0);
   sd_dat=14;repeat(3)@(negedge sd_clk);sd_dat=15;
  end
  16: begin
   cmd16_seen=cmd16_seen+1;if(arg!=512)fail("CMD16 length");response48(16,32'h900,0);
  end
  6: begin if(arg!=2)fail("ACMD6 width");response48(6,32'h900,0);end
  17,18: begin
   lba=mode==0?arg:(arg>>9);
   if(lba!=expected_lba)fail("read address / SDSC addressing");
   if(mode==1 && arg[8:0]!=0)fail("SDSC byte address alignment");
   if(cmd==17 && expected_blocks!=1)fail("wrong single-block command");
   if(cmd==18 && expected_blocks<=1)fail("wrong multi-block command");
   response48(cmd,32'h900,0);
   fork send_blocks(expected_blocks,lba,corrupt!=0); join_none
  end
  12: begin
   stops_seen=stops_seen+1;response48(12,32'h900,0);
   sd_dat=14;repeat(3)@(negedge sd_clk);sd_dat=15;
  end
  default: fail($sformatf("unexpected CMD%0d",cmd));
 endcase
end
endtask
always @(posedge sd_clk) begin
 if(rst)begin command_bits=0;command_frame=0;end
 else if(!card_cmd_enable)begin
  if(command_bits==0)begin
   if(sd_cmd===1'b0)begin command_frame=0;command_bits=1;end
  end else begin
   command_frame={command_frame[46:0],sd_cmd};command_bits=command_bits+1;
   if(command_bits==48)begin command_bits=0;handle_command(command_frame);end
  end
 end
end
always @(posedge clk)begin
 if(monitor_reads && read_valid)begin
  if(read_data!==(((bytes_seen%512)+(bytes_seen/512)+expected_lba)&255))
   fail($sformatf("payload byte %0d = %02x",bytes_seen,read_data));
  bytes_seen=bytes_seen+1;
 end
 if(monitor_reads && block_end)blocks_seen=blocks_seen+1;
end
task automatic read_test(input integer lba,input integer count,input integer bad);
begin
 expected_lba=lba;expected_blocks=count;corrupt=bad;
 bytes_seen=0;blocks_seen=0;monitor_reads=1;
 @(negedge clk);read_lba=lba;read_blocks=count;read_start=1;
 @(negedge clk);read_start=0;
 wait(read_done);#1;
 if(read_error!==(bad!=0))fail("transaction error flag");
 if(bytes_seen!=512*count)fail($sformatf("byte count %0d",bytes_seen));
 if(blocks_seen!=(bad?0:count))fail($sformatf("block count %0d",blocks_seen));
 if(bad!=0) begin if(!card_error || card_ready)fail("CRC failure should mark card unavailable"); end else if(card_error || !card_ready)fail("card unavailable after good read");
 monitor_reads=0;
 $display("READ lba=%0d blocks=%0d badcrc=%0d passed at %0t",lba,count,bad,$time);
 repeat(5)@(posedge clk);
end
endtask
initial begin
 #100 rst=0;wait(card_ready || card_error);
 if(card_error)begin fail("SDHC init");$finish;end
 $display("SDHC init passed %0t",$time);
 read_test('h123,3,0);
 if(stops_seen!=1)fail("CMD18 did not send CMD12");
 read_test('h44,1,1); @(negedge clk);force dut.retry_count=27'd99999999; @(posedge clk);#1;
 if(dut.retry_reset_count!=32 || !dut.link_reset)fail("CRC retry reset");
 @(negedge clk);release dut.retry_count;wait(!dut.link_reset);wait(card_ready || card_error);
 if(card_error || !card_ready)fail("CRC automatic reinitialization");
 $display("CRC ERROR POLICY AND AUTOMATIC REINITIALIZATION PASSED");
 read_test('h45,1,0);
 mode=1;rst=1;repeat(10)@(negedge clk);rst=0;
 wait(card_ready || card_error);
 if(card_error)begin fail("legacy SDSC init");$finish;end
 if(cmd16_seen!=1)fail("SDSC missing CMD16");
 $display("SDSC init passed %0t",$time);
 read_test('h321,1,0);
 // Accelerate only the one-second wait; check the real retry reset and init.
 @(negedge clk);force dut.card_error=1;force dut.retry_count=27'd99999999;
 @(posedge clk);#1;
 if(dut.retry_reset_count!=32 || !dut.link_reset)fail("retry reset not asserted");
 @(negedge clk);release dut.retry_count;release dut.card_error;
 wait(!dut.link_reset);wait(card_ready || card_error);
 if(card_error || !card_ready)fail("retry initialization");
 $display("AUTOMATIC REINITIALIZATION PASSED");
 if(errors==0)$display("ALL NATIVE SD CHECKS PASSED");
 else $display("%0d ERRORS",errors);
 $finish;
end
initial begin #100000000;fail("test timeout");$finish;end
endmodule


