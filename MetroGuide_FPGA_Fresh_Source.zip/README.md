# MetroGuide_FPGA_Fresh

This archive contains the MetroGuide FPGA project source tree prepared from `MetroGuide_FPGA_Fresh`: RTL, board constraints, IP source/configuration, simulation testbenches, helper scripts, project files, documentation, and release BIT files.

The four user audio files are stored separately in the repository at `assets/audio_tf/1.wav` through `4.wav`.

Large video frame BMP files and generated video BIN files are not included in this GitHub source package. They must be copied to the TF card separately for full video playback. Generated TD run/cache folders are also omitted.

Target board: Anlogic EG4S20BG256. Project tool: TD 6.2.1 Engineer 6.2.168116.
