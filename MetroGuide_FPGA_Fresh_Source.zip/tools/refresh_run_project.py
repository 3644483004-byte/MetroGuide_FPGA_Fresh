"""Refresh both Anlogic run manifests from the .al source list."""

from __future__ import annotations

import pathlib
from datetime import datetime
import xml.etree.ElementTree as ET


ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT_NAME = "MetroGuide_FPGA_Fresh"
AL_FILE = ROOT / f"{PROJECT_NAME}.al"
for run_name in ("syn_1", "phy_1"):
    tree = ET.parse(AL_FILE)
    project = tree.getroot()
    project.attrib.pop("Path", None)
    project.set("RunTime", datetime.now().isoformat(timespec="seconds"))
    for file_node in project.findall("./Source_Files/Verilog/File"):
        file_node.set("Path", "../../" + file_node.attrib["Path"])
    for file_node in project.findall("./Source_Files/ADC_FILE/File"):
        file_node.set("Path", "../../" + file_node.attrib["Path"])
    for file_node in project.findall("./Source_Files/SDC_FILE/File"):
        file_node.set("Path", "../../" + file_node.attrib["Path"])
    out_file = ROOT / f"{PROJECT_NAME}_Runs" / run_name / f"{PROJECT_NAME}.prj"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    tree.write(out_file, encoding="utf-8", xml_declaration=True)
    print(f"Wrote {out_file}")
