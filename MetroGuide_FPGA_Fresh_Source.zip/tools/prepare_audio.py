#!/usr/bin/env python3
"""Prepare the four source WAVs for the board's 48 kHz HDMI audio path.

The generated files are ordinary, canonical PCM WAV files (stereo, 16-bit,
48 kHz, 44-byte RIFF header). Inputs may be 44.1 kHz or already 48 kHz. Copy
1.wav through 4.wav from the output folder to the root of a FAT32 TF card.
"""

from __future__ import annotations

import argparse
import array
import pathlib
import wave

SUPPORTED_SOURCE_RATES = (44_100, 48_000)
TARGET_RATE = 48_000
TRACKS = ("1.wav", "2.wav", "3.wav", "4.wav")


def resample_stereo(samples: array.array[int], source_frames: int,
                    source_rate: int) -> array.array[int]:
    """Linear-interpolate signed interleaved stereo PCM to 48 kHz."""
    out_frames = (source_frames * TARGET_RATE + source_rate // 2) // source_rate
    result = array.array("h")
    if samples.itemsize != 2:
        raise ValueError("This Python runtime must use 16-bit array('h') samples")

    for out_index in range(out_frames):
        source_pos = out_index * source_rate
        left_index, fraction = divmod(source_pos, TARGET_RATE)
        if left_index >= source_frames:
            left_index = source_frames - 1
            fraction = 0
        right_index = min(left_index + 1, source_frames - 1)
        for channel in (0, 1):
            a = samples[left_index * 2 + channel]
            b = samples[right_index * 2 + channel]
            value = (a * (TARGET_RATE - fraction) + b * fraction)
            value = (value + TARGET_RATE // 2) // TARGET_RATE if value >= 0 else -((-value + TARGET_RATE // 2) // TARGET_RATE)
            result.append(max(-32768, min(32767, value)))
    return result


def convert(source: pathlib.Path, destination: pathlib.Path) -> tuple[int, int]:
    with wave.open(str(source), "rb") as wav:
        source_rate = wav.getframerate()
        if (wav.getnchannels() != 2 or wav.getsampwidth() != 2 or
                source_rate not in SUPPORTED_SOURCE_RATES or wav.getcomptype() != "NONE"):
            raise ValueError(
                f"{source.name}: expected stereo 16-bit PCM at 44100 or 48000 Hz; "
                f"got channels={wav.getnchannels()}, width={wav.getsampwidth()}, "
                f"rate={source_rate}, compression={wav.getcomptype()}"
            )
        frames = wav.getnframes()
        raw = wav.readframes(frames)

    source_samples = array.array("h")
    source_samples.frombytes(raw)
    if __import__("sys").byteorder != "little":
        source_samples.byteswap()
    converted = (source_samples if source_rate == TARGET_RATE else
                 resample_stereo(source_samples, frames, source_rate))
    if __import__("sys").byteorder != "little":
        converted.byteswap()

    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), "wb") as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(TARGET_RATE)
        wav.writeframes(converted.tobytes())
    return len(converted) // 2, destination.stat().st_size


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=pathlib.Path, required=True, help="Folder containing 1.wav..4.wav")
    parser.add_argument("--output", type=pathlib.Path, required=True, help="Folder for card-ready 1.wav..4.wav")
    args = parser.parse_args()

    for filename in TRACKS:
        source = args.source / filename
        destination = args.output / filename
        frames, size = convert(source, destination)
        print(f"{filename}: {frames} frames, {frames / TARGET_RATE:.3f} s, {size} bytes")


if __name__ == "__main__":
    main()
