#!/usr/bin/env python3
"""Build a complete 10 fps FAT32 root-directory package from the four BMP sets."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import struct
import sys
import wave
from pathlib import Path

try:
    import numpy as np
except ImportError as exc:
    raise SystemExit("This tool needs NumPy; use the Python environment bundled with the project.") from exc

WIDTH = 640
HEIGHT = 480
FPS = 10
SOURCE_COUNTS = (784, 563, 784, 754)
SCENE_FILES = ("V1.BIN", "V2.BIN", "V3.BIN", "V4.BIN")
BYTES_PER_FRAME = WIDTH * HEIGHT * 2


def natural_key(path: Path) -> list[object]:
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r"(\d+)", path.name)]


def audio_info(path: Path) -> dict[str, int | float | str]:
    try:
        with wave.open(str(path), "rb") as wav:
            info = {
                "channels": wav.getnchannels(),
                "sample_rate_hz": wav.getframerate(),
                "sample_width_bytes": wav.getsampwidth(),
                "sample_frames": wav.getnframes(),
                "compression": wav.getcomptype(),
            }
    except (OSError, wave.Error) as exc:
        raise ValueError(f"{path.name}: invalid WAV ({exc})") from exc
    if (info["channels"] != 2 or info["sample_rate_hz"] != 48_000 or
            info["sample_width_bytes"] != 2 or info["compression"] != "NONE" or
            info["sample_frames"] <= 0):
        raise ValueError(f"{path.name}: expected stereo 48 kHz 16-bit PCM WAV")
    info["duration_seconds"] = info["sample_frames"] / info["sample_rate_hz"]
    return info


def bmp_to_rgb565(path: Path) -> bytes:
    data = path.read_bytes()
    if len(data) < 54 or data[:2] != b"BM":
        raise ValueError(f"{path.name}: not a BMP file")
    pixel_offset = struct.unpack_from("<I", data, 10)[0]
    dib_size = struct.unpack_from("<I", data, 14)[0]
    if dib_size < 40 or len(data) < 14 + dib_size:
        raise ValueError(f"{path.name}: unsupported BMP header")
    width, signed_height = struct.unpack_from("<ii", data, 18)
    planes, bits_per_pixel = struct.unpack_from("<HH", data, 26)
    compression = struct.unpack_from("<I", data, 30)[0]
    if (width != WIDTH or abs(signed_height) != HEIGHT or planes != 1 or
            bits_per_pixel != 24 or compression != 0):
        raise ValueError(f"{path.name}: expected uncompressed 640x480 24-bit BMP")
    stride = (width * 3 + 3) & ~3
    end = pixel_offset + stride * HEIGHT
    if pixel_offset < 14 + dib_size or end > len(data):
        raise ValueError(f"{path.name}: truncated pixel data")
    rows = np.frombuffer(data, dtype=np.uint8, count=stride * HEIGHT,
                         offset=pixel_offset).reshape(HEIGHT, stride)
    if signed_height > 0:
        rows = rows[::-1]
    bgr = rows[:, :WIDTH * 3].reshape(HEIGHT, WIDTH, 3).astype(np.uint16)
    blue, green, red = bgr[:, :, 0], bgr[:, :, 1], bgr[:, :, 2]
    rgb565 = ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3)
    return rgb565.astype("<u2", copy=False).tobytes(order="C")


def select_frames(frames: list[Path], count: int) -> list[Path]:
    if count < 1 or count > len(frames):
        raise ValueError(f"cannot select {count} output frames from {len(frames)} source frames")
    if count == 1:
        return [frames[0]]
    denominator = count - 1
    return [frames[(2 * i * (len(frames) - 1) + denominator) // (2 * denominator)]
            for i in range(count)]


def pack_scene(frames: list[Path], output: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    temp = output.with_suffix(output.suffix + ".tmp")
    with temp.open("wb") as out:
        for i, frame in enumerate(frames, 1):
            packed = bmp_to_rgb565(frame)
            if len(packed) != BYTES_PER_FRAME:
                raise ValueError(f"{frame.name}: incorrect converted frame size")
            out.write(packed)
            digest.update(packed)
            if i % 100 == 0 or i == len(frames):
                print(f"{output.name}: {i}/{len(frames)} frames")
    expected = len(frames) * BYTES_PER_FRAME
    if temp.stat().st_size != expected:
        temp.unlink(missing_ok=True)
        raise ValueError(f"{output.name}: packed size mismatch")
    temp.replace(output)
    return expected, digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for n in range(1, 5):
        parser.add_argument(f"--scene{n}", type=Path, required=True)
    parser.add_argument("--audio-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        print(f"error: output directory must be empty: {output}", file=sys.stderr)
        return 2

    scenes = []
    total_bytes = 0
    try:
        for number, (source_count, filename) in enumerate(zip(SOURCE_COUNTS, SCENE_FILES), 1):
            source_dir = getattr(args, f"scene{number}")
            frames = sorted((p for p in source_dir.iterdir()
                             if p.is_file() and p.suffix.casefold() == ".bmp"),
                            key=natural_key)
            if len(frames) != source_count:
                raise ValueError(f"{source_dir}: expected {source_count} BMP files, found {len(frames)}")
            audio_path = args.audio_dir / f"{number}.wav"
            audio = audio_info(audio_path)
            sample_rate = int(audio["sample_rate_hz"])
            sample_frames = int(audio["sample_frames"])
            target_count = (sample_frames * FPS + sample_rate - 1) // sample_rate
            selected = select_frames(frames, target_count)
            size, sha256 = pack_scene(selected, output / filename)
            shutil.copy2(audio_path, output / audio_path.name)
            total_bytes += size + audio_path.stat().st_size
            scenes.append({
                "scene": number,
                "file": filename,
                "frames": target_count,
                "source_frames": source_count,
                "fps": FPS,
                "duration_seconds": audio["duration_seconds"],
                "bytes": size,
                "sha256": sha256,
                "audio": audio,
                "selection": "uniformly sampled across first-to-last source frame",
            })
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    manifest = {
        "format": "RGB565_LE",
        "width": WIDTH,
        "height": HEIGHT,
        "bytes_per_frame": BYTES_PER_FRAME,
        "video_fps": FPS,
        "filesystem_requirement": "FAT32",
        "card_layout": "copy 1.wav..4.wav and V1.BIN..V4.BIN to the TF card root",
        "scenes": scenes,
        "total_media_bytes": total_bytes,
    }
    (output / "VIDEO.JSON").write_text(json.dumps(manifest, indent=2) + "\n",
                                       encoding="utf-8")
    print(f"Complete TF-card package: {output}")
    print(f"Video frames: {[scene['frames'] for scene in scenes]}")
    print(f"Approximate media total: {total_bytes:,} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())